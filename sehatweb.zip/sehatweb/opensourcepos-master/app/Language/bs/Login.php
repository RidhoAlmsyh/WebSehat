<?php
return [
	"gcaptcha" => "Ja nisam robot.",
	"go" => "Idi",
	"invalid_gcaptcha" => "Molimo potvrdite da niste robot.",
	"invalid_installation" => "Instalacija nije ispravna, provjerite vašu php.ini datoteku.",
	"invalid_username_and_password" => "Pogrešno korisničko ime i/ili lozinka.",
	"login" => "Prijava",
	"logout" => "Odjava",
	"migration_needed" => "Migracija baze podataka na {0} će početi nakon prijavljivanja.",
	"password" => "Lozinka",
	"required_username" => "",
	"username" => "Korisničko ime",
	"welcome" => "Dobrodošli u {0}!",
];
