<?php
return [
	"first_name" => "Ime",
	"last_name" => "Prezime",
	"message" => "Poruka",
	"message_placeholder" => "Vaša poruka ovdje ...",
	"message_required" => "Poruka je obavezna",
	"multiple_phones" => "(U slučaju više primalaca, unesite mobilne brojeve odvojene zarezima)",
	"phone" => "Telefonski broj",
	"phone_number_required" => "Broj telefona je obavezan",
	"phone_placeholder" => "Broj mobilnog telefona ovde...",
	"sms_send" => "Pošalji SMS",
	"successfully_sent" => "Poruka je uspješno poslata: ",
	"unsuccessfully_sent" => "Poruka nije uspešno poslata: ",
];
