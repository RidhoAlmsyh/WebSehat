<?php
return [
	"no_permission_module" => "Nemate dozvolu za pristup modulu",
	"unknown" => "Neočekivana greška",
];
