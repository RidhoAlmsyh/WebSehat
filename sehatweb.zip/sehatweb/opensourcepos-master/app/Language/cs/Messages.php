<?php
return [
	"first_name" => "Jméno",
	"last_name" => "Příjmení",
	"message" => "Zpráva",
	"message_placeholder" => "Zde napište zprávu...",
	"message_required" => "Zprávu je nutno napsat",
	"multiple_phones" => "(V případě více adresátů oddělujte čísla na mobil čárkami)",
	"phone" => "Telefonní číslo",
	"phone_number_required" => "Telefonní číslo je vyžadováno",
	"phone_placeholder" => "Telefonní číslo...",
	"sms_send" => "Odeslat SMS",
	"successfully_sent" => "Zpráva byla odeslána: ",
	"unsuccessfully_sent" => "Zpráva nebyla odeslána: ",
];
