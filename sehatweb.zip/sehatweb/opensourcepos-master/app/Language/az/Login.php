<?php
return [
	"gcaptcha" => "Mən robot deyiləm.",
	"go" => "daxil ol",
	"invalid_gcaptcha" => "Robot olmadığınızı təsdiqləyin.",
	"invalid_installation" => "Quraşdırma düzgün deyil, php.ini faylını yoxlayın.",
	"invalid_username_and_password" => "Yanlış istifadəçi adı və ya şifrə.",
	"login" => "Giriş",
	"logout" => "Çıxış",
	"migration_needed" => "{0} -ə daxil olandan sonra verilənlər bazası miqrasiyası başlayacaq.",
	"password" => "Şifrə",
	"required_username" => "",
	"username" => "İstifadəçi",
	"welcome" => "{0} -ə xoş gəlmisiniz!",
];
