<?php
 return [
    'gcaptcha' => "أنا لست روبوتاً.",
    'go' => "البَدْء",
    'invalid_gcaptcha' => "يرجى التحقق من أنك لست روبوتًا.",
    'invalid_installation' => "يوجد مشكلة بالتنصيب, الرجاء التحقق من ملف php.ini.",
    'invalid_username_and_password' => "اسم المستخدم/كلمة المرور غير صحيحة.",
    'login' => "دخول",
    'logout' => "تسجيل خروج",
    'migration_needed' => "سيبدأ ترحيل قاعدة البيانات إلى{0} بعد تسجيل الدخول.",
    'password' => "كلمة السر",
    'required_username' => "خانة أسم المستخدم مطلوبة.",
    'username' => "اسم المستخدم",
    'welcome' => "مرحباً بك في{0}!",
];
