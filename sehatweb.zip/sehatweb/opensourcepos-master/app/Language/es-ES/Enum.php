<?php
return [
	"half_down" => "Mitad abajo",
	"half_even" => "Mitad par",
	"half_five" => "Mitad y cinco",
	"half_odd" => "Mitad impar",
	"half_up" => "Mitad arriba",
	"round_down" => "Redondeo abajo",
	"round_up" => "Redondeo arriba",
];
