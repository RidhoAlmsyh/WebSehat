<?php
return [
	"first_name" => "Nombre",
	"last_name" => "Apellidos",
	"message" => "Mensaje",
	"message_placeholder" => "Su mensaje aquí…",
	"message_required" => "Mensaje es requerido",
	"multiple_phones" => "(En Caso de varios destinatarios, ingresar los numeros de telefono separados por comas)",
	"phone" => "Numero de Telefono",
	"phone_number_required" => "El Telefono es requerido",
	"phone_placeholder" => "Numero de Celular aquí…",
	"sms_send" => "Enviar SMS",
	"successfully_sent" => "Mensaje exitosamente enviado a: ",
	"unsuccessfully_sent" => "Mensaje no pudo ser enviado a: ",
];
