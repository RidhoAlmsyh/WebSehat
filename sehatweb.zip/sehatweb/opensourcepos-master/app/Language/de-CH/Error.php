<?php
return [
	"no_permission_module" => "Sie haben nicht die Zugangsrechte für das gewählte Modul",
	"unknown" => "Unbekannter Fehler",
];
