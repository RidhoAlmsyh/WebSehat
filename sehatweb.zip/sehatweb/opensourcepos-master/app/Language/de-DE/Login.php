<?php
return [
	"gcaptcha" => "Ich bin kein Roboter.",
	"go" => "Los",
	"invalid_gcaptcha" => "Ich bin kein Roboter ist ungültig.",
	"invalid_installation" => "Die Installation ist nicht korrekt, überprüfen Sie Ihre php.ini-Datei.",
	"invalid_username_and_password" => "Ungültiger Benutzername oder Passwort.",
	"login" => "Login",
	"logout" => "",
	"migration_needed" => "",
	"password" => "Passwort",
	"required_username" => "",
	"username" => "Benutzername",
	"welcome" => "",
];
