<?php
return [
	"no_permission_module" => "You do not have permission to access the module named",
	"unknown" => "Unexpected error",
];
